# Partenariat Simplon
## Une Simple Extention WordPress

### Description :
plugin partenariat simplon, permet d'afficher un texte donné dans n'importe quel post ou page.
...

### Installation :
dans extensions, cliquez sur "ajouter" rajouter WPaulina.zip
...

### Utilisation :
dans les pages souhaitées, inscrire [WPaulina] pour afficher le résultat de l'extension créée.
...

### Ressources :
#### Déclaration du plugin :
https://openclassrooms.com/courses/propulsez-votre-site-avec-wordpress/creer-des-plugins#r-1892278  
https://developer.wordpress.org/plugins/the-basics/header-requirements/

#### Shortcodes :
https://www.sitepoint.com/wordpress-shortcodes-tutorial/ - chapitre Simple Shortcodes 
